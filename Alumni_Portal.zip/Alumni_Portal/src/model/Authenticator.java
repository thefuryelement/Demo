package model;

public class Authenticator 
{
	public String authenticate(String username, String password) {
		if (("root".equalsIgnoreCase(username))&&("root".equals(password))) 
		{
			return "success";
		}
		else
		{
			return "failure";
		}
	}
}
