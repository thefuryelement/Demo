package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Authenticator;
import model.MySqlConn;
import model.User;

@WebServlet(name = "login", urlPatterns = { "/login" })
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	public LoginController() 
	{
		super();
	}
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
	{
		String param = request.getParameter("action");
		RequestDispatcher rd = null;
		Connection con = null;
		if(param.equals("login"))
		{
			String username = request.getParameter("username");
			String password = request.getParameter("password");

			con = MySqlConn.getNewConnection();
			try 
			{
				ResultSet rs = con.createStatement().executeQuery("Select username, password from login where username="+username+"password="+password);
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}

			Authenticator authenticator = new Authenticator();

			String result = authenticator.authenticate(username, password);
			if (result.equals("success")) 
			{
				rd = request.getRequestDispatcher("/success.jsp");
				User user = new User(username, password);
				request.setAttribute("user", user);
			} 
			else 
			{
				rd = request.getRequestDispatcher("/signup.jsp");
			}
			rd.forward(request, response);
		}
		else if(param.equals("signup"))
		{
			rd = request.getRequestDispatcher("/signup.jsp");
		}
	}
 
}